package com.visionai.mobile

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class AssistantStore(context: Context) {
    private val prefs = context.getSharedPreferences("vision_ai_store", Context.MODE_PRIVATE)

    fun addNote(text: String) {
        val a = JSONArray(prefs.getString("notes", "[]"))
        a.put(JSONObject().put("text", text).put("time", System.currentTimeMillis()))
        prefs.edit().putString("notes", a.toString()).apply()
    }

    fun notes(): String {
        val a = JSONArray(prefs.getString("notes", "[]"))
        if (a.length() == 0) return "உங்கள் notes எதுவும் இல்லை."
        val out = StringBuilder("உங்கள் notes: ")
        for (i in 0 until a.length()) out.append(a.getJSONObject(i).optString("text")).append(". ")
        return out.toString()
    }

    fun setSalary(amount: String) {
        prefs.edit().putString("salary", amount).apply()
    }

    fun salary(): String {
        return prefs.getString("salary", null)?.let { "உங்கள் சேமித்த salary ₹$it." }
            ?: "Salary இன்னும் சேமிக்கப்படவில்லை."
    }

    fun addBudget(item: String) {
        val a = JSONArray(prefs.getString("budget", "[]"))
        a.put(item)
        prefs.edit().putString("budget", a.toString()).apply()
    }

    fun budget(): String {
        val a = JSONArray(prefs.getString("budget", "[]"))
        if (a.length() == 0) return "Budget தகவல் இல்லை."
        val out = StringBuilder("Budget: ")
        for (i in 0 until a.length()) out.append(a.getString(i)).append(". ")
        return out.toString()
    }
}
