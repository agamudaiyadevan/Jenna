package com.visionai.mobile

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object TimeUtil {
    fun timeTamil(): String {
        val now = Date()
        val t = SimpleDateFormat("h:mm", Locale("ta", "IN")).format(now)
        val hour = SimpleDateFormat("HH", Locale.US).format(now).toInt()
        val part = when (hour) {
            in 0..11 -> "காலை"
            in 12..15 -> "மதியம்"
            in 16..18 -> "மாலை"
            else -> "இரவு"
        }
        return "இப்போது நேரம் $t. $part."
    }

    fun dateTamil(): String {
        return SimpleDateFormat("dd MMMM yyyy, EEEE", Locale("ta", "IN")).format(Date())
    }
}
