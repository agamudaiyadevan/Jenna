package com.visionai.mobile

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import java.util.*

class VoiceService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private lateinit var store: AssistantStore
    private var listening = false

    override fun onCreate() {
        super.onCreate()
        store = AssistantStore(this)
        createChannel()
        startForeground(44, notification("VISION AI குரல் உதவியாளர் இயங்குகிறது"))
        tts = TextToSpeech(this, this)
        startRecognition()
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("vision_voice", "VISION AI Voice", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun notification(text: String): Notification =
        NotificationCompat.Builder(this, "vision_voice")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("VISION AI")
            .setContentText(text)
            .setOngoing(true)
            .build()

    private fun startRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("இந்த மொபைலில் voice recognition கிடைக்கவில்லை.")
            return
        }
        if (Build.VERSION.SDK_INT >= 23 &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(this)

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ta-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ta-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 700)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 300)
        }
        listening = true
        recognizer?.startListening(intent)
    }

    override fun onResults(results: Bundle?) {
        val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val text = list?.firstOrNull()?.trim().orEmpty()
        if (text.isNotBlank()) handle(text)
        restartSoon()
    }

    override fun onError(error: Int) { restartSoon() }
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() { restartSoon() }
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}

    private fun restartSoon() {
        if (!listening) return
        Handler(Looper.getMainLooper()).postDelayed({ startRecognition() }, 350)
    }

    private fun handle(text: String) {
        // Wake word: the assistant responds only when the user says "Jenna".
        val normalized = text.trim()
        val q = normalized.lowercase(Locale("ta", "IN"))
        val wakeWordPattern = Regex("(?i)(^|\\s)(jenna|ஜென்னா|ஜெனா)(?=\\s|$)")
        if (!wakeWordPattern.containsMatchIn(normalized)) return

        val command = wakeWordPattern.replace(normalized, " ").trim()
        if (command.isBlank()) {
            speak("ஆம், நான் கேட்கிறேன்.")
            return
        }

        val commandQ = command.lowercase(Locale("ta", "IN"))

        when {
            commandQ.contains("நேரம்") || commandQ.contains("மணி") || commandQ.contains("time") ->
                speak(TimeUtil.timeTamil())

            commandQ.contains("தேதி") || commandQ.contains("date") || commandQ.contains("நாள்") ->
                speak("இன்றைய தேதி ${TimeUtil.dateTamil()}.")

            commandQ.contains("note") || commandQ.contains("நோட்") || commandQ.contains("நோட்ஸ்") ->
                if (commandQ.contains("சொல்") || commandQ.contains("காட்டு") || commandQ.contains("என்ன")) speak(store.notes())
                else {
                    val value = command.replace(Regex("(?i).*?(note|நோட்|நோட்ஸ்)"), "").trim()
                    if (value.isNotBlank()) { store.addNote(value); speak("Note சேமித்துவிட்டேன்.") }
                    else speak(store.notes())
                }

            commandQ.contains("salary") || commandQ.contains("சம்பளம்") ->
                if (commandQ.contains("என்ன") || commandQ.contains("சொல்") || commandQ.contains("காட்டு")) speak(store.salary())
                else {
                    val amount = text.filter { it.isDigit() }
                    if (amount.isNotBlank()) { store.setSalary(amount); speak("Salary ₹$amount என்று சேமித்துவிட்டேன்.") }
                    else speak("Salary தொகையை சொல்லுங்கள்.")
                }

            commandQ.contains("budget") || commandQ.contains("பட்ஜெட்") ->
                if (commandQ.contains("என்ன") || commandQ.contains("சொல்") || commandQ.contains("காட்டு")) speak(store.budget())
                else { store.addBudget(command); speak("Budget தகவலை சேமித்துவிட்டேன்.") }

            commandQ.contains("பாடல்") || commandQ.contains("song") || commandQ.contains("music") ->
                speak("பாடலை app-க்குள் காட்டுகிறேன்.")

            else -> askBackend(command)
        }
    }

    private fun askBackend(text: String) {
        Thread {
            try {
                val url = java.net.URL("${ApiConfig.BASE_URL}/api/chat")
                val conn = url.openConnection() as java.net.HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json")
                conn.doOutput = true
                val body = JSONObject().put("message", text).toString()
                conn.outputStream.use { it.write(body.toByteArray()) }
                val response = conn.inputStream.bufferedReader().readText()
                val answer = JSONObject(response).optString("answer", "மன்னிக்கவும், பதில் கிடைக்கவில்லை.")
                Handler(Looper.getMainLooper()).post { speak(answer) }
            } catch (_: Exception) {
                Handler(Looper.getMainLooper()).post { speak("AI server-ஐ இப்போது தொடர்பு கொள்ள முடியவில்லை.") }
            }
        }.start()
    }

    private fun speak(text: String) {
        Handler(Looper.getMainLooper()).post {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "vision-answer")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val locale = Locale("ta", "IN")
            tts?.language = locale
            // Prefer a female Tamil voice when the device exposes one.
            val candidate = tts?.voices?.firstOrNull {
                it.locale.language == "ta" &&
                (it.name.contains("female", true) || it.name.contains("woman", true))
            }
            if (candidate != null) tts?.voice = candidate
            tts?.setSpeechRate(1.08f)
        }
    }

    override fun onDestroy() {
        listening = false
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
