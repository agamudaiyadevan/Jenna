package com.visionai.mobile

object ApiConfig {
    // Example: https://your-domain.example
    const val BASE_URL = "https://YOUR-BACKEND.example"
}
