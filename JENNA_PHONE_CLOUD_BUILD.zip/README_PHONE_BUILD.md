# Jenna — phone-only APK build

இந்த project-ஐ GitHub repository-க்கு upload செய்த பிறகு GitHub Actions மூலம் APK build செய்யலாம்.
Computer தேவையில்லை.

1. GitHub-ல் புதிய repository உருவாக்கவும்.
2. இந்த project-ன் files-ஐ repository-க்கு upload செய்யவும்.
3. `Actions` → `Build Jenna APK` → `Run workflow`.
4. Build முடிந்ததும் workflow-ல் `Jenna-debug-apk` artifact-ஐ download செய்யவும்.
5. Android-ல் APK-ஐ install செய்யவும்.

இந்த workflow GitHub-hosted runner-ல் Java 17 + Gradle 8.10.2 வைத்து debug APK build செய்கிறது.
