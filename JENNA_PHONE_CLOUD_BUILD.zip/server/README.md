# VISION AI backend

1. `npm install`
2. Set `OPENAI_API_KEY`
3. Optional: set `OPENAI_MODEL`
4. `npm start`

Keep the API key on the server, never inside the Android APK.
