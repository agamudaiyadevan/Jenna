import express from "express";
import OpenAI from "openai";

const app = express();
app.use(express.json({ limit: "1mb" }));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const MODEL = process.env.OPENAI_MODEL || "gpt-6.1-sol";

app.post("/api/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({ error: "message required" });

    const response = await client.responses.create({
      model: MODEL,
      input: [
        {
          role: "system",
          content:
            "You are VISION AI, a fast Tamil-first personal mobile assistant. " +
            "Answer naturally in Tamil unless the user asks for another language. " +
            "Be concise for voice output. Never claim an action was completed unless it actually was. " +
            "For current time, the Android app handles it locally."
        },
        { role: "user", content: message }
      ]
    });

    res.json({ answer: response.output_text || "மன்னிக்கவும், பதில் கிடைக்கவில்லை." });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "AI request failed" });
  }
});

app.get("/health", (_, res) => res.json({ ok: true, service: "VISION AI" }));

app.listen(process.env.PORT || 8080, "0.0.0.0", () => {
  console.log("VISION AI server running");
});
