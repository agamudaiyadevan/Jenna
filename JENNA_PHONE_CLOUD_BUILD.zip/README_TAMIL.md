# VISION AI — Android Voice Assistant

இது Android-க்கு voice-first assistant project.

## முக்கிய அம்சங்கள்
- எந்த visible button-மும் இல்லாத voice-first screen
- Tamil speech recognition (`ta-IN`)
- Wake word: **Jenna** — “Jenna” என்று அழைத்த பிறகே command-க்கு பதிலளிக்கும்
- App திறந்தவுடன் listening தொடங்கும்; recognition முடிந்ததும் மீண்டும் listening முயற்சிக்கும்
- பெண் Tamil TTS voice கிடைத்தால் தேர்வு செய்ய முயற்சி; இல்லையெனில் device-ன் Tamil voice fallback
- நேரம் / தேதி — device local time மூலம் உடனடி பதில்
- Notes, budget, salary, reminders — local Android storage
- AI answers — secure backend `/api/chat`
- பாடல் கேட்கும்போது app-க்குள் YouTube embedded player
- Home Assistant REST control hook for Wi‑Fi smart devices
- Bluetooth device discovery hook
- Android foreground microphone service

## முக்கிய குறிப்பு
“24/7” Android-ல் absolute guarantee அல்ல. Android battery optimization, microphone restrictions, OEM background limits போன்றவை service-ஐ நிறுத்தலாம். இந்த project foreground microphone service பயன்படுத்துகிறது; பயனர் microphone/notification permissions கொடுக்க வேண்டும்.

SpeechRecognizer-ஐ நீண்ட நேரம் தொடர்ச்சியாக வைத்திருப்பது Android-ல் device-dependent. Production version-ல் dedicated wake-word engine + foreground service பயன்படுத்துவது இன்னும் நம்பகமானது.

## AI backend
API key-ஐ Android app-ல் வைக்க வேண்டாம். Backend-ல் `OPENAI_API_KEY` environment variable ஆக வையுங்கள்.

Backend:
    cd server
    npm install
    OPENAI_API_KEY=... npm start

அதன் பிறகு Android app-ன் `ApiConfig.kt`-ல் backend URL அமைக்கவும்.

## Smart devices
Home Assistant பயன்படுத்தினால்:
- `HOME_ASSISTANT_URL`
- long-lived access token

இவற்றை backend அல்லது secure app configuration-ல் அமைத்து `/api/device` route-க்கு அனுப்பலாம்.

Arbitrary Bluetooth devices-ஐ பொதுவாக ஒரே generic command மூலம் control செய்ய முடியாது; ஒவ்வொரு BLE device-க்கும் அதன் GATT protocol தேவை.
